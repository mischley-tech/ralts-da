package com.hoenn.raltspet

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast

class MainActivity : Activity() {
    companion object {
        const val ACTION_START_SCREEN_WALKER = "com.hoenn.raltspet.ACTION_START_SCREEN_WALKER"
        private const val REQ_OVERLAY_PERMISSION = 4021
    }

    private lateinit var webView: WebView

    inner class AndroidWidgetBridge(private val context: Context) {
        @JavascriptInterface
        fun updateWidgetData(
            nickname: String,
            species: String,
            level: Int,
            stage: Int,
            hunger: Int,
            happiness: Int,
            isShiny: Boolean
        ) {
            val prefs = context.getSharedPreferences("ralts_emerald_prefs", Context.MODE_PRIVATE)
            prefs.edit()
                .putString("nickname", nickname)
                .putString("species", species)
                .putInt("level", level)
                .putInt("stage", stage)
                .putInt("hunger", hunger)
                .putInt("happiness", happiness)
                .putBoolean("isShiny", isShiny)
                .putLong("last_decay_ms", System.currentTimeMillis())
                .putBoolean("widget_dirty", false)
                .apply()
            RaltsWidgetProvider.updateAllWidgets(context)
        }

        @JavascriptInterface
        fun toggleScreenWalker(): Boolean {
            return runOnUiThreadResult {
                if (RaltsOverlayService.isRunning) {
                    stopService(Intent(this@MainActivity, RaltsOverlayService::class.java))
                    false
                } else {
                    requestOrStartScreenWalker()
                    RaltsOverlayService.isRunning
                }
            }
        }

        @JavascriptInterface
        fun isScreenWalkerActive(): Boolean {
            return RaltsOverlayService.isRunning
        }
    }

    private fun runOnUiThreadResult(block: () -> Boolean): Boolean {
        if (!Settings.canDrawOverlays(this)) {
            runOnUiThread { requestOrStartScreenWalker() }
            return false
        }
        var res = false
        val latch = java.util.concurrent.CountDownLatch(1)
        runOnUiThread {
            res = block()
            latch.countDown()
        }
        try {
            latch.await(1, java.util.concurrent.TimeUnit.SECONDS)
        } catch (_: Exception) {}
        return res
    }

    fun requestOrStartScreenWalker() {
        if (Settings.canDrawOverlays(this)) {
            val svc = Intent(this, RaltsOverlayService::class.java)
            startService(svc)
            Toast.makeText(
                this,
                "💚 Ralts is now walking on your screen! Tap Ralts to pet, drag to move, or double-tap to recall.",
                Toast.LENGTH_LONG
            ).show()
        } else {
            Toast.makeText(
                this,
                "Toggle ON 'Allow display over other apps' so Ralts can walk across your screen!",
                Toast.LENGTH_LONG
            ).show()
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            @Suppress("DEPRECATION")
            startActivityForResult(intent, REQ_OVERLAY_PERMISSION)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_OVERLAY_PERMISSION) {
            if (Settings.canDrawOverlays(this)) {
                startService(Intent(this, RaltsOverlayService::class.java))
                Toast.makeText(
                    this,
                    "💚 Ralts is now walking on your screen! Tap Ralts to pet!",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)

        val settings: WebSettings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.mediaPlaybackRequiresUserGesture = false

        webView.addJavascriptInterface(AndroidWidgetBridge(this), "AndroidWidgetBridge")
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                syncFromWidgetIfNeeded()
            }
        }
        webView.loadUrl("file:///android_asset/index.html")
        handleIncomingIntent(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        handleIncomingIntent(intent)
    }

    private fun handleIncomingIntent(intent: Intent?) {
        if (intent?.action == ACTION_START_SCREEN_WALKER) {
            requestOrStartScreenWalker()
        }
    }

    override fun onResume() {
        super.onResume()
        RaltsWidgetProvider.applyElapsedDecay(this)
        syncFromWidgetIfNeeded()
    }

    private fun syncFromWidgetIfNeeded() {
        val prefs = getSharedPreferences("ralts_emerald_prefs", Context.MODE_PRIVATE)
        if (prefs.getBoolean("widget_dirty", false)) {
            val level = prefs.getInt("level", 5)
            val stage = prefs.getInt("stage", 0)
            val hunger = prefs.getInt("hunger", 84)
            val happiness = prefs.getInt("happiness", 88)
            prefs.edit().putBoolean("widget_dirty", false).apply()
            webView.evaluateJavascript(
                "if(window.receiveWidgetSync){window.receiveWidgetSync($level,$stage,$hunger,$happiness);}",
                null
            )
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
