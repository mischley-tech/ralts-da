# Ralts Emerald Pet — Walking & Pettable Home Screen Widget + Screen Roamer

This complete Android project (`com.hoenn.raltspet`) for Google Pixel includes **two ways** for Ralts to walk around and be petted on your phone:

1. **Interactive Walking Habitat Widget (On Your Home Screen)**:
   - Displays a wide **Route 102 Grass Habitat** where Ralts (or Kirlia / Gardevoir) strolls back and forth.
   - **Tap directly on Ralts** inside the widget (or tap **💚 Pet**) to pet Ralts! Ralts jumps happily with floating pixel hearts (`♥`), steps to a new spot in the grass, and gains `+12% Happiness`.
   - Tap **🐾 Step** to make Ralts walk across the widget habitat, or **🍇 Feed** to feed an Oran Berry and level up!
2. **Full-Screen Walking Pet Mode (`RaltsOverlayService.kt` — "🚶 Screen Walk")**:
   - Tap **🚶 Screen Walk** on the widget (or **Walk on Screen** at the top of the app) to summon Ralts out of the widget so it **walks freely across your entire Pixel screen** at 25 FPS over your home screen and other apps!
   - **Tap Ralts** anywhere on your screen to pet it (spawns floating `💚` hearts, happy jump animation, and speech bubble).
   - **Drag Ralts** with your finger to carry and place it anywhere on your screen.
   - **Double-tap Ralts** (or tap **🏠 Recall** on the widget) to send Ralts back home into the widget.
